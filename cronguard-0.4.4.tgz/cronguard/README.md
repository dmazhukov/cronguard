# CronGuard Helm chart

SLO-style observability operator for Kubernetes CronJobs.

The operator watches CronJobs and Jobs in the cluster (or a single namespace) and reconciles a `CronJobMonitor` custom resource that captures the SLO state — consecutive failures, missed runs, schedule drift, and recent execution history. Each monitor exports Prometheus metrics under `cronguard_*` so you can alert on schedule and execution health.

## Installing

### Via OCI registry (Helm 3.8+)

```bash
helm install cronguard oci://ghcr.io/dmazhukov/charts/cronguard --version 0.4.3 \
  --namespace cronguard-system --create-namespace
```

### Via GitHub Pages Helm repo

```bash
helm repo add cronguard https://dmazhukov.github.io/cronguard/
helm repo update
helm install cronguard cronguard/cronguard --version 0.4.3 \
  --namespace cronguard-system --create-namespace
```

### Via local chart checkout

```bash
helm install cronguard ./charts/cronguard \
  --namespace cronguard-system --create-namespace
```

## Uninstalling

```bash
helm uninstall cronguard -n cronguard-system
```

The CRD is **not** removed by `helm uninstall` (Helm's design for `crds/`, unchanged in Helm 4). Drop it explicitly when you want to forget the operator:

```bash
kubectl delete crd cronjobmonitors.monitoring.cronguard.io
```

## Values

| Key | Type | Default | Description |
| --- | --- | --- | --- |
| `image.repository` | string | `ghcr.io/dmazhukov/cronguard` | Operator image repository. |
| `image.pullPolicy` | string | `IfNotPresent` | Image pull policy. One of `Always`, `IfNotPresent`, `Never`. |
| `image.tag` | string | `""` | Image tag. Empty string defaults to `.Chart.AppVersion`. |
| `imagePullSecrets` | list | `[]` | Secret names for pulling private images. |
| `extraArgs` | list | `[]` | Extra command-line args appended to the manager binary (e.g. `--zap-log-level=2`). |
| `extraEnv` | list | `[]` | Extra environment variables added to the manager container (standard `EnvVar` specs). |
| `nameOverride` | string | `""` | Override the chart name component of resource names. |
| `fullnameOverride` | string | `""` | Override the entire resource name. |
| `replicaCount` | integer | `1` | Operator replicas. Set to `2` for HA — leader election keeps one reconciler active. |
| `namespace` | string | `""` | Restrict the operator to a single namespace. Empty means cluster-wide watch. |
| `leaderElection.enabled` | boolean | `true` | Toggle leader election. |
| `serviceAccount.create` | boolean | `true` | Create the operator ServiceAccount. |
| `serviceAccount.name` | string | `""` | ServiceAccount name. Empty defaults to the chart fullname. |
| `serviceAccount.annotations` | object | `{}` | Annotations on the ServiceAccount (e.g. IRSA / Workload Identity). |
| `resources.requests.cpu` | string | `10m` | Container CPU request. |
| `resources.requests.memory` | string | `64Mi` | Container memory request. |
| `resources.limits.cpu` | string | `500m` | Container CPU limit. |
| `resources.limits.memory` | string | `256Mi` | Container memory limit. |
| `maxConcurrentReconciles` | integer | `1` | Monitors reconciled in parallel (`--max-concurrent-reconciles`). |
| `metrics.port` | integer | `8080` | Prometheus `/metrics` listener port. |
| `metrics.secure` | boolean | `false` | Serve `/metrics` over TLS with a self-signed certificate generated at startup (`--metrics-secure`). It stops passive capture of the scrape and authenticates neither side (the scraper cannot verify a self-signed certificate): pair it with `networkPolicy`. The chart's `ServiceMonitor` switches to `https` without certificate verification. |
| `healthProbe.port` | integer | `8081` | Liveness and readiness probe port. |
| `serviceMonitor.enabled` | boolean | `false` | Render a `ServiceMonitor` for prometheus-operator. |
| `serviceMonitor.namespace` | string | `""` | Namespace for the `ServiceMonitor`. Empty defaults to release namespace. |
| `serviceMonitor.labels` | object | `{}` | Extra labels on the `ServiceMonitor`. |
| `serviceMonitor.interval` | string | `30s` | Scrape interval. |
| `serviceMonitor.scrapeTimeout` | string | `10s` | Scrape timeout. |
| `serviceMonitor.honorLabels` | boolean | `false` | Pass through `honorLabels` to scrape config. Not needed for the monitor's `namespace` label: the ServiceMonitor copies it back from `exported_namespace` either way. |
| `prometheusRule.enabled` | boolean | `false` | Render a `PrometheusRule` with seven default CronGuard alerts (4 SLO-axis + 2 burn-rate + Operator Down). `CronGuardOperatorDown` matches on the release namespace only when `serviceMonitor.enabled` is set, because the namespace label comes from that scrape; without it the alert watches for any CronGuard, so it stays quiet while another installation scraped by the same Prometheus is up. |
| `prometheusRule.namespace` | string | `""` | Namespace for the `PrometheusRule`. Empty defaults to release namespace. |
| `prometheusRule.labels` | object | `{}` | Extra labels on the `PrometheusRule`. |
| `prometheusRule.interval` | string | `30s` | Rule evaluation interval. |
| `prometheusRule.thresholds.scheduleMissed.for` | string | `5m` | `for:` duration for `CronGuardScheduleMissed`. |
| `prometheusRule.thresholds.scheduleMissed.severity` | string | `warning` | Severity label for `CronGuardScheduleMissed`. |
| `prometheusRule.thresholds.consecutiveFailures.for` | string | `5m` | `for:` duration for `CronGuardConsecutiveFailures`. |
| `prometheusRule.thresholds.consecutiveFailures.severity` | string | `warning` | Severity label for `CronGuardConsecutiveFailures`. |
| `prometheusRule.thresholds.durationExceeded.for` | string | `1m` | `for:` duration for `CronGuardDurationExceeded`. |
| `prometheusRule.thresholds.durationExceeded.severity` | string | `info` | Severity label for `CronGuardDurationExceeded`. |
| `prometheusRule.thresholds.notReady.for` | string | `10m` | `for:` duration for `CronGuardNotReady`. |
| `prometheusRule.thresholds.notReady.severity` | string | `critical` | Severity label for `CronGuardNotReady`. |
| `prometheusRule.thresholds.operatorDown.for` | string | `2m` | `for:` duration for `CronGuardOperatorDown`. |
| `prometheusRule.thresholds.operatorDown.severity` | string | `critical` | Severity label for `CronGuardOperatorDown`. |
| `prometheusRule.thresholds.missedRunsBurnFast.fastRate` | number | `1` | Fast-window burn rate (missed runs/min over 5m). |
| `prometheusRule.thresholds.missedRunsBurnFast.slowRate` | number | `6` | Fast-window second condition (missed runs/hour over 1h). |
| `prometheusRule.thresholds.missedRunsBurnFast.for` | string | `2m` | `for:` duration for `CronGuardMissedRunsBurnFast`. |
| `prometheusRule.thresholds.missedRunsBurnFast.severity` | string | `warning` | Severity label. |
| `prometheusRule.thresholds.missedRunsBurnSlow.fastRate` | number | `1` | Slow-window burn rate (missed runs/hour over 1h). |
| `prometheusRule.thresholds.missedRunsBurnSlow.slowRate` | number | `3` | Slow-window second condition (missed runs over 6h). |
| `prometheusRule.thresholds.missedRunsBurnSlow.for` | string | `15m` | `for:` duration for `CronGuardMissedRunsBurnSlow`. |
| `prometheusRule.thresholds.missedRunsBurnSlow.severity` | string | `info` | Severity label. |
| `crds.install` | boolean | `true` | Deprecated, ignored. Use `helm install --skip-crds` to skip the CRD. |
| `podAnnotations` | object | `{}` | Annotations applied to operator pods. |
| `podLabels` | object | `{}` | Extra labels applied to operator pods. |
| `podSecurityContext` | object | runAsNonRoot, runAsUser 65532, RuntimeDefault seccomp | Pod-level security context. |
| `securityContext` | object | drop ALL caps, no privilege escalation, read-only root FS | Container-level security context. |
| `nodeSelector` | object | `{}` | Node selector. |
| `tolerations` | list | `[]` | Tolerations. |
| `affinity` | object | `{}` | Affinity rules. |
| `topologySpreadConstraints` | list | `[]` | Spread pods across failure domains. Relevant when `replicaCount > 1`. |
| `podDisruptionBudget.enabled` | boolean | `false` | Render a `PodDisruptionBudget`. Only meaningful when `replicaCount > 1`. |
| `podDisruptionBudget.minAvailable` | integer | `1` | Minimum available pods (mutually exclusive with `maxUnavailable`). |
| `podDisruptionBudget.maxUnavailable` | integer | _unset_ | Maximum unavailable pods (mutually exclusive with `minAvailable`). |
| `networkPolicy.enabled` | boolean | `false` | Render an ingress-only `NetworkPolicy` for the operator pod. `/metrics` is plain HTTP without authentication; on a CNI that enforces NetworkPolicy this limits who can read it. The health port stays open for kubelet probes, egress is not restricted. |
| `networkPolicy.metricsFrom` | list | `[]` | `NetworkPolicyPeer` entries allowed to scrape `/metrics`, e.g. `namespaceSelector.matchLabels."kubernetes.io/metadata.name": monitoring`. Required when enabled: a rule with no peers would admit every source, so the chart refuses to render. |
| `priorityClassName` | string | `""` | Pod priority class. |
| `terminationGracePeriodSeconds` | integer | `30` | Pod termination grace period. |

## Upgrading

`helm upgrade` rolls Deployment, Service, RBAC, and ServiceMonitor templates. The CRD is **not** touched on upgrade — Helm installs CRDs from `crds/` only on `helm install`, in Helm 4 as in Helm 3 (checked with 4.2.3, with and without `--server-side`). To upgrade the schema:

```bash
kubectl apply -f charts/cronguard/crds/cronjobmonitors.yaml
helm upgrade cronguard ./charts/cronguard -n cronguard-system
```

## CRD management notes

The chart ships the CRD in `crds/cronjobmonitors.yaml`. Helm treats `crds/` specially, in Helm 3 and Helm 4 alike: contents are installed once on `helm install` and ignored on `helm upgrade`. If you manage CRDs externally — for example, a separate `kubectl apply` step in your delivery pipeline — install with `helm install --skip-crds`. The `crds.install` value never controlled this and is ignored.

## Examples

### Single-namespace install

```bash
helm install cronguard ./charts/cronguard \
  -n cronguard-system --create-namespace \
  --set namespace=production
```

The operator only watches CronJobs and Jobs in the `production` namespace.

### HA install

```bash
helm install cronguard ./charts/cronguard \
  -n cronguard-system --create-namespace \
  --set replicaCount=2
```

Two replicas with leader election (default-on). Only one is active at a time; failover is automatic.

With `replicaCount > 1` AND `serviceMonitor.enabled=true`, the chart's ServiceMonitor adds a `relabelings: keep regex: leader` rule keyed on the `cronguard.io/role` pod label. Only the elected leader pod is scraped — without this, both pods would serve `/metrics` with identical labels and Prometheus would double-count every gauge. The standby pod is patched with `cronguard.io/role: standby` and remains visible in the Service's endpoints (for kubelet liveness/readiness traffic) but excluded from scrape.

### ServiceMonitor enabled

```bash
helm install cronguard ./charts/cronguard \
  -n cronguard-system --create-namespace \
  --set serviceMonitor.enabled=true \
  --set serviceMonitor.labels.release=prometheus
```

The `release: prometheus` label is what the kube-prometheus-stack chart selects on by default.

## PrometheusRule (alerts)

Set `prometheusRule.enabled: true` to ship seven default alerts as a `PrometheusRule` resource. Requires prometheus-operator CRDs in the cluster.

```yaml
prometheusRule:
  enabled: true
  thresholds:
    scheduleMissed:
      for: 5m
      severity: warning
```

Override individual thresholds via `--set prometheusRule.thresholds.scheduleMissed.for=10m`.

The standalone manifest at `config/prometheus/rules.yaml` is the same set of rules without the chart's templating, suitable for users not on Helm.

## Compatibility

- Kubernetes `>= 1.28`
- Helm `>= 3.8` for OCI installs

## License

Apache-2.0
